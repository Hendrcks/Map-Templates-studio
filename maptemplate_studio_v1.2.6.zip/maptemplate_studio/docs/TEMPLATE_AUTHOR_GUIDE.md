# MapTemplate Studio — Template Author Guide

This guide describes how cartographers, GIS managers, and organizations can design custom `.qpt` templates that integrate seamlessly with MapTemplate Studio's automated role-binding and preflight validation engine.

---

## 1. Stable Item ID Convention

When designing a layout in QGIS Layout Designer, assign meaningful **Item IDs** in the *Item Properties* panel so that MapTemplate Studio can bind dynamic project data, extents, and user marginalia.

### 1.1 Map Viewport IDs
| Item ID | Role | Required? | Behavior |
|---|---|---|---|
| `main_map` | Primary map viewport | Yes | Bounds to active layer/canvas, sets primary scale and coordinate reference system. |
| `locator_map` | Regional / overview inset | Optional | Receives regional overview extent or country boundaries. |
| `before_map` | Baseline condition (twin panel) | Optional | Receives Date T1 layers in split-compare layouts. |
| `after_map` | Comparison condition (twin panel) | Optional | Receives Date T2 layers in split-compare layouts. |

### 1.2 Cartographic Marginalia IDs
| Item ID | Target Layout Item | Bound Value |
|---|---|---|
| `title` | QgsLayoutItemLabel | Map Title entered in wizard. |
| `subtitle` | QgsLayoutItemLabel | Subtitle, study area, or analytical scope. |
| `source` / `sources` | QgsLayoutItemLabel | Data sources and scientific provenance. |
| `author` | QgsLayoutItemLabel | Cartographer or institutional author. |
| `organization` | QgsLayoutItemLabel | Client, agency, or ministry name. |
| `date` | QgsLayoutItemLabel | Publication month/year. |
| `crs` | QgsLayoutItemLabel | Coordinate reference system description. |
| `notes` | QgsLayoutItemLabel | Methodology disclaimer or survey field notes. |
| `logo` | QgsLayoutItemPicture | Institutional logo image path. |

### 1.3 Apparatus IDs
| Item ID | Target Layout Item | Automated Linkage |
|---|---|---|
| `legend_main` | QgsLayoutItemLegend | Automatically linked to `main_map`; respects column count and extent filters. |
| `scale_main` | QgsLayoutItemScaleBar | Automatically linked to `main_map`; respects metric/imperial units. |
| `north_arrow` | QgsLayoutItemPicture | Automatically linked to `main_map` rotation; falls back to standard SVG arrow. |

---

## 2. Template Manifest Specification

Each template directory must contain a `manifest.json` file conforming to `schema/template-manifest-v1.schema.json`:

```json
{
  "schema_version": "1.0",
  "id": "CORP-01",
  "display_name": "Corporate Standard Report",
  "family": "planning",
  "archetype": "right_rail",
  "version": "1.0.0",
  "description": "Standard corporate report layout with right-hand metadata sidebar.",
  "author": "Corporate GIS Team",
  "source": "original",
  "license": "Internal / Proprietary",
  "qpt_path": "layout.qpt",
  "preview_path": "preview.png",
  "page": {
    "sizes": ["A4"],
    "orientations": ["portrait"]
  },
  "map_roles": [
    {
      "id": "main_map",
      "required": true,
      "fit": "canvas_extent",
      "description": "Main project study area"
    }
  ],
  "fields": ["title", "subtitle", "source", "author", "date", "crs"],
  "style_tags": ["corporate", "report", "portrait"],
  "export_presets": ["pdf_print_300", "png_digital_4k"],
  "assets": [],
  "compatibility": {
    "qgis_3_44": "compatible",
    "qgis_4_2": "compatible"
  }
}
```

---

## 3. Directory Layout for a Template Pack

```text
templates/
  CORP-01/
    manifest.json
    layout.qpt
    preview.png
    assets/         (optional logos or SVGs)
```

---

## 4. Best Practices for High-Resolution Printing

1. **Page Margins**: Maintain safe margins of 10–12 mm on A4 sheets and 14–16 mm on A3 sheets to account for physical printer gripper margins.
2. **Typography**: Ensure body text is at least 7.5–9 pt at actual print scale. Avoid text below 6 pt.
3. **Frames & Dividers**: Use hairline or 0.2–0.4 mm borders for crisp, non-distracting visual hierarchy.
4. **Scale Bars**: Use round unit intervals (e.g. 1 km, 5 km, 10 km) rather than awkward fractional increments.
