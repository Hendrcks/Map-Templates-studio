"""
Main Gallery Dock Widget for MapTemplate Studio.
Features search filtering, category navigation, card gallery, and template inspector.
Maintains 100% theme consistency with QGIS Software UI theme.
"""

import os
from typing import Optional, Dict, Any, List

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
    from qgis.PyQt.QtCore import Qt, pyqtSignal
    from qgis.PyQt.QtWidgets import (
        QDockWidget,
        QWidget,
        QVBoxLayout,
        QHBoxLayout,
        QSplitter,
        QLabel,
        QLineEdit,
        QComboBox,
        QListWidget,
        QListWidgetItem,
        QPushButton,
        QToolButton,
        QScrollArea,
        QFrame,
        QGridLayout,
        QMessageBox,
    )
    from qgis.gui import (
        QgsFilterLineEdit,
    )
    from qgis.core import QgsProject
    HAS_QGIS_GUI = True
except ImportError:
    HAS_QGIS_GUI = False

try:
    from ..core.catalog_service import CatalogService
    from ..core.settings_service import SettingsService
    from ..core.layout_factory import LayoutFactory
    from .theme import QGISTheme
    from .template_model import TemplateCardWidget
    from .wizard_dialog import WizardDialog
    from .import_template_dialog import ImportTemplateDialog
    from .export_dialog import ExportDialog
except (ImportError, ValueError):
    from core.catalog_service import CatalogService
    from core.settings_service import SettingsService
    from core.layout_factory import LayoutFactory
    from ui.theme import QGISTheme
    from ui.template_model import TemplateCardWidget
    from ui.wizard_dialog import WizardDialog
    from ui.import_template_dialog import ImportTemplateDialog
    from ui.export_dialog import ExportDialog


class MapTemplateDockWidget(QDockWidget):
    """QGIS Dockable Studio for browsing, configuring, and generating map templates."""

    def __init__(self, iface=None, parent=None):
        super().__init__("MapTemplate Studio", parent)
        self.iface = iface
        self.setObjectName("MapTemplateDockWidget")
        self.setAllowedAreas(
            Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea
        )

        self.settings = SettingsService()
        self.catalog = CatalogService(settings=self.settings)

        self.selected_template: Optional[Dict[str, Any]] = None
        self._card_widgets: Dict[str, TemplateCardWidget] = {}

        self._init_ui()
        self.setStyleSheet(QGISTheme.get_gallery_stylesheet())
        self.refresh_gallery()

    def _init_ui(self):
        container = QWidget(self)
        container.setObjectName("MapTemplateGallery")
        main_layout = QVBoxLayout(container)
        main_layout.setContentsMargins(6, 6, 6, 6)
        main_layout.setSpacing(6)

        # 1. Top Header & Search Bar
        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(0, 0, 0, 0)
        top_bar.setSpacing(6)

        # Search field (uses QgsFilterLineEdit if available)
        if HAS_QGIS_GUI:
            self.search_edit = QgsFilterLineEdit(container)
        else:
            self.search_edit = QLineEdit(container)
        self.search_edit.setPlaceholderText("Search templates by name, keyword, or role...")
        self.search_edit.textChanged.connect(self._on_filter_changed)
        top_bar.addWidget(self.search_edit)

        # Archetype Filter Combo
        self.arch_combo = QComboBox(container)
        self.arch_combo.addItem("All Archetypes", "all")
        self.arch_combo.addItem("Hero Map", "hero_map")
        self.arch_combo.addItem("Right Rail", "right_rail")
        self.arch_combo.addItem("Bottom Band", "bottom_band")
        self.arch_combo.addItem("Split Compare", "split_compare")
        self.arch_combo.addItem("Dashboard", "dashboard")
        self.arch_combo.addItem("Atlas Sheet", "atlas_sheet")
        self.arch_combo.currentIndexChanged.connect(self._on_filter_changed)
        top_bar.addWidget(self.arch_combo)

        # Paper Size Filter Combo
        self.size_combo = QComboBox(container)
        self.size_combo.addItem("All Sizes", "all")
        self.size_combo.addItem("A4", "A4")
        self.size_combo.addItem("A3", "A3")
        self.size_combo.addItem("A2", "A2")
        self.size_combo.addItem("16:9", "16:9")
        self.size_combo.currentIndexChanged.connect(self._on_filter_changed)
        top_bar.addWidget(self.size_combo)

        # Import Template Button
        self.import_btn = QToolButton(container)
        self.import_btn.setText("＋ Import")
        self.import_btn.setToolTip("Import a custom .qpt template")
        self.import_btn.clicked.connect(self._open_import_dialog)
        top_bar.addWidget(self.import_btn)

        # Refresh Button
        self.refresh_btn = QToolButton(container)
        self.refresh_btn.setText("↻")
        self.refresh_btn.setToolTip("Reload Template Catalog")
        self.refresh_btn.clicked.connect(self.refresh_gallery)
        top_bar.addWidget(self.refresh_btn)

        main_layout.addLayout(top_bar)

        # 2. Main Horizontal Splitter (Category List | Gallery Cards | Inspector)
        splitter = QSplitter(Qt.Orientation.Horizontal, container)

        # Left: Category / Collections List
        self.cat_list = QListWidget(splitter)
        self.cat_list.setMaximumWidth(190)
        self.cat_list.setMinimumWidth(140)
        self._populate_categories()
        self.cat_list.currentRowChanged.connect(self._on_category_changed)
        splitter.addWidget(self.cat_list)

        # Center: Card Gallery in Scroll Area
        self.scroll_area = QScrollArea(splitter)
        self.scroll_area.setWidgetResizable(True)
        self.gallery_widget = QWidget()
        self.grid_layout = QGridLayout(self.gallery_widget)
        self.grid_layout.setContentsMargins(8, 8, 8, 8)
        self.grid_layout.setSpacing(10)
        self.scroll_area.setWidget(self.gallery_widget)
        splitter.addWidget(self.scroll_area)

        # Right: Selected Template Inspector Panel
        self.inspector_panel = self._create_inspector_panel(splitter)
        splitter.addWidget(self.inspector_panel)

        # Set splitter proportions: Left 18%, Center 52%, Right 30%
        splitter.setSizes([170, 480, 260])
        main_layout.addWidget(splitter)

        self.setWidget(container)

    def _populate_categories(self):
        self.cat_list.clear()
        counts = self.catalog.get_counts()
        fams = counts["families"]

        cats = [
            ("📁 All Templates", "all", counts["total"]),
            ("★ Favorites", "favorites", counts["favorites"]),
            ("🕒 Recently Used", "recent", counts["recently_used"]),
            ("🌐 General & Reference", "general", fams.get("general", 0)),
            ("🏛 Planning & Land", "planning", fams.get("planning", 0)),
            ("🛰 Remote Sensing", "remote_sensing", fams.get("remote_sensing", 0)),
            ("🌊 Environment & Hazards", "environment", fams.get("environment", 0)),
            ("⛰ Terrain & Topography", "terrain", fams.get("terrain", 0)),
            ("👥 Population & Social", "social", fams.get("social", 0)),
            ("🚗 Transport & Cities", "transport", fams.get("transport", 0)),
            ("🚨 Humanitarian & Safety", "humanitarian", fams.get("humanitarian", 0)),
            ("📐 Surveying & Cadastre", "surveying", fams.get("surveying", 0)),
            ("🗺 Atlas & Series", "atlas", fams.get("atlas", 0)),
            ("🎓 Academic Figures", "academic", fams.get("academic", 0)),
            ("💻 Digital & Widescreen", "digital", fams.get("digital", 0)),
        ]

        for label, cat_id, count in cats:
            item = QListWidgetItem(f"{label} ({count})")
            item.setData(Qt.ItemDataRole.UserRole, cat_id)
            self.cat_list.addItem(item)

        self.cat_list.setCurrentRow(0)

    def _create_inspector_panel(self, parent) -> QWidget:
        panel = QWidget(parent)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # Inspector Preview Image
        self.insp_preview = QLabel(panel)
        self.insp_preview.setFixedHeight(160)
        self.insp_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.insp_preview.setStyleSheet("background-color: palette(base); border-radius: 4px;")
        layout.addWidget(self.insp_preview)

        # Title & ID
        self.insp_title = QLabel("Select a template", panel)
        self.insp_title.setStyleSheet("font-size: 12pt; font-weight: bold;")
        self.insp_title.setWordWrap(True)
        layout.addWidget(self.insp_title)

        # Badges row
        self.insp_badges = QHBoxLayout()
        self.insp_id_pill = QLabel("", panel)
        self.insp_id_pill.setObjectName("BadgePill")
        self.insp_badges.addWidget(self.insp_id_pill)

        self.insp_arch_pill = QLabel("", panel)
        self.insp_arch_pill.setObjectName("BadgePill")
        self.insp_badges.addWidget(self.insp_arch_pill)

        self.insp_size_pill = QLabel("", panel)
        self.insp_size_pill.setObjectName("BadgePill")
        self.insp_badges.addWidget(self.insp_size_pill)

        self.insp_badges.addStretch()
        layout.addLayout(self.insp_badges)

        # Description
        self.insp_desc = QLabel("", panel)
        self.insp_desc.setWordWrap(True)
        self.insp_desc.setStyleSheet("color: palette(mid); font-size: 9pt;")
        layout.addWidget(self.insp_desc)

        # Map Roles specification
        self.insp_roles = QLabel("", panel)
        self.insp_roles.setWordWrap(True)
        self.insp_roles.setStyleSheet("font-size: 8.5pt;")
        layout.addWidget(self.insp_roles)

        layout.addStretch()

        # Action Buttons
        self.wizard_btn = QPushButton("✓ Create Layout...", panel)
        self.wizard_btn.setObjectName("PrimaryButton")
        self.wizard_btn.clicked.connect(self._open_wizard_for_selected)
        layout.addWidget(self.wizard_btn)

        self.quick_draft_btn = QPushButton("⚡ Quick Draft from Canvas", panel)
        self.quick_draft_btn.setObjectName("SecondaryButton")
        self.quick_draft_btn.setToolTip("Creates layout instantly using current canvas view and active layers.")
        self.quick_draft_btn.clicked.connect(self._create_quick_draft)
        layout.addWidget(self.quick_draft_btn)

        return panel

    def refresh_gallery(self):
        """Reloads catalog and rebuilds the card grid."""
        self.catalog.reload()
        self._populate_categories()
        self._filter_and_render_cards()

    def _on_category_changed(self, row):
        self._filter_and_render_cards()

    def _on_filter_changed(self):
        self._filter_and_render_cards()

    def _filter_and_render_cards(self):
        # Clear existing cards from grid
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self._card_widgets.clear()

        # Determine filters
        cat_item = self.cat_list.currentItem()
        cat_id = cat_item.data(Qt.ItemDataRole.UserRole) if cat_item else "all"

        favorites_only = (cat_id == "favorites")
        recent_only = (cat_id == "recent")
        family = None if cat_id in ("all", "favorites", "recent") else cat_id

        arch = self.arch_combo.currentData()
        size = self.size_combo.currentData()
        query = self.search_edit.text().strip()

        templates = self.catalog.filter(
            query=query,
            family=family,
            archetype=arch,
            page_size=size,
            favorites_only=favorites_only,
            recent_only=recent_only,
        )

        # Render cards into grid (2 columns)
        cols = 2
        for idx, t_data in enumerate(templates):
            row = idx // cols
            col = idx % cols
            card = TemplateCardWidget(t_data, self.gallery_widget)
            card.clicked.connect(self._on_card_clicked)
            card.doubleClicked.connect(self._on_card_double_clicked)
            card.favoriteToggled.connect(self._on_favorite_toggled)

            self.grid_layout.addWidget(card, row, col)
            self._card_widgets[t_data["id"]] = card

        # Select first card if available
        if templates:
            self._select_template(templates[0]["id"])
        else:
            self._clear_inspector()

    def _select_template(self, template_id: str):
        # Deselect previous
        if self.selected_template and self.selected_template["id"] in self._card_widgets:
            self._card_widgets[self.selected_template["id"]].set_selected(False)

        self.selected_template = self.catalog.get_template(template_id)
        if self.selected_template and template_id in self._card_widgets:
            self._card_widgets[template_id].set_selected(True)
            self._update_inspector(self.selected_template)

    def _on_card_clicked(self, template_id: str):
        self._select_template(template_id)

    def _on_card_double_clicked(self, template_id: str):
        self._select_template(template_id)
        self._open_wizard_for_selected()

    def _on_favorite_toggled(self, template_id: str):
        self.settings.toggle_favorite(template_id)
        # Update category counts
        self._populate_categories()

    def _update_inspector(self, data: Dict[str, Any]):
        self.insp_title.setText(data.get("display_name", ""))
        self.insp_id_pill.setText(data.get("id", ""))
        self.insp_arch_pill.setText(data.get("archetype", "").replace("_", " ").title())
        page_sizes = data.get("page", {}).get("sizes", ["A4"])
        self.insp_size_pill.setText(page_sizes[0])

        self.insp_desc.setText(data.get("description", ""))

        roles = data.get("map_roles", [])
        roles_text = "<b>Map Viewports:</b><br/>" + "<br/>".join([
            f"• <b>{r.get('id')}</b>: {r.get('description', '')}" for r in roles
        ])
        self.insp_roles.setText(roles_text)

        preview_path = data.get("preview_abs_path")
        if preview_path and os.path.isfile(preview_path):
            pix = QtGui.QPixmap(preview_path).scaled(
                240, 160, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation
            )
            self.insp_preview.setPixmap(pix)
        else:
            self.insp_preview.setText("No Preview")

        self.wizard_btn.setEnabled(True)
        self.quick_draft_btn.setEnabled(True)

    def _clear_inspector(self):
        self.selected_template = None
        self.insp_title.setText("No template matching filter")
        self.insp_id_pill.setText("")
        self.insp_arch_pill.setText("")
        self.insp_size_pill.setText("")
        self.insp_desc.setText("Try adjusting your search keywords or category filters.")
        self.insp_roles.setText("")
        self.insp_preview.setText("")
        self.wizard_btn.setEnabled(False)
        self.quick_draft_btn.setEnabled(False)

    def _open_wizard_for_selected(self):
        if not self.selected_template:
            return
        wizard = WizardDialog(self.selected_template, iface=self.iface, parent=self)
        wizard.exec()

    def _create_quick_draft(self):
        """Immediately creates a layout using current project map canvas view and active layers."""
        if not self.selected_template:
            return

        role_layers = {}
        role_extents = {}

        if self.iface:
            canvas = self.iface.mapCanvas()
            ext = canvas.extent()
            layers = canvas.layers()
            for r in self.selected_template.get("map_roles", []):
                r_id = r["id"]
                role_layers[r_id] = layers
                role_extents[r_id] = ext

        metadata = {
            "title": f"{self.selected_template.get('display_name')} (Draft)",
            "subtitle": "Generated via MapTemplate Studio Quick Draft",
            "source": "Active QGIS Project Data",
            "author": self.settings.get_default_author() or "Cartography Unit",
            "organization": self.settings.get_default_organization() or "GIS Division",
            "date": "2026",
            "crs": QgsProject.instance().crs().description() if HAS_QGIS_GUI else "WGS 84",
        }

        layout, err = LayoutFactory.create_layout_from_template(
            qpt_path=self.selected_template.get("qpt_abs_path"),
            layout_name=f"{self.selected_template.get('display_name')} Draft",
            role_layers=role_layers,
            role_extents=role_extents,
            metadata=metadata,
            project=QgsProject.instance(),
        )

        if layout:
            self.settings.record_used_template(self.selected_template["id"])
            if self.iface and hasattr(self.iface, "openLayoutDesigner"):
                try:
                    self.iface.openLayoutDesigner(layout)
                except Exception:
                    self.settings.set_value("last_layout_created", layout.name())
            QMessageBox.information(
                self,
                "Quick Draft Created",
                f"Layout '{layout.name()}' created successfully in your project!",
            )
        else:
            QMessageBox.critical(self, "Draft Failed", f"Could not create quick draft:\n{err}")

    def _open_import_dialog(self):
        dlg = ImportTemplateDialog(self)
        dlg.templateImported.connect(lambda t_id: self.refresh_gallery())
        dlg.exec()
