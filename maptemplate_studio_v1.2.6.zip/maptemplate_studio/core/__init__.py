"""
Core module for MapTemplate Studio.
"""
