"""
Manifest Validator for MapTemplate Studio.
Validates template manifest definitions against the schema rules.
"""

import os
import re
from typing import Dict, Any, List, Tuple


VALID_FAMILIES = {
    "general",
    "planning",
    "remote_sensing",
    "environment",
    "terrain",
    "social",
    "transport",
    "humanitarian",
    "surveying",
    "atlas",
    "academic",
    "digital",
}

VALID_ARCHETYPES = {
    "hero_map",
    "right_rail",
    "bottom_band",
    "split_compare",
    "dashboard",
    "atlas_sheet",
}

from .paper_sizes import PaperSizeRegistry

VALID_PAGE_SIZES = PaperSizeRegistry.get_valid_manifest_sizes()
VALID_ORIENTATIONS = {"landscape", "portrait"}
ID_REGEX = re.compile(r"^[A-Z]{2,4}-[0-9]{2}$")
SEMVER_REGEX = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+$")


class ManifestValidator:
    """Validates template manifest dictionaries and manifest files."""

    @classmethod
    def validate_dict(cls, data: Dict[str, Any], base_dir: str = None) -> Tuple[bool, List[str]]:
        errors: List[str] = []

        if not isinstance(data, dict):
            return False, ["Manifest root must be a JSON object."]

        # Required fields
        required_fields = [
            "schema_version",
            "id",
            "display_name",
            "family",
            "archetype",
            "version",
            "license",
            "qpt_path",
            "page",
            "map_roles",
            "fields",
        ]
        for field in required_fields:
            if field not in data or data[field] is None:
                errors.append(f"Missing required field: '{field}'")

        if errors:
            return False, errors

        # ID format
        template_id = str(data.get("id", ""))
        if not ID_REGEX.match(template_id):
            errors.append(f"Invalid 'id' format '{template_id}'. Must match pattern 'AAA-00'.")

        # Version
        version = str(data.get("version", ""))
        if not SEMVER_REGEX.match(version):
            errors.append(f"Invalid 'version' format '{version}'. Must follow semantic versioning (e.g. 1.0.0).")

        # Family
        family = data.get("family")
        if family not in VALID_FAMILIES:
            errors.append(f"Invalid 'family' '{family}'. Must be one of: {sorted(VALID_FAMILIES)}")

        # Archetype
        archetype = data.get("archetype")
        if archetype not in VALID_ARCHETYPES:
            errors.append(f"Invalid 'archetype' '{archetype}'. Must be one of: {sorted(VALID_ARCHETYPES)}")

        # Page
        page = data.get("page")
        if not isinstance(page, dict):
            errors.append("'page' must be an object with 'sizes' and 'orientations'.")
        else:
            sizes = page.get("sizes", [])
            if not isinstance(sizes, list) or not sizes:
                errors.append("'page.sizes' must be a non-empty list.")
            else:
                for sz in sizes:
                    if sz not in VALID_PAGE_SIZES:
                        errors.append(f"Unsupported page size '{sz}'. Supported: {sorted(VALID_PAGE_SIZES)}")

            orientations = page.get("orientations", [])
            if not isinstance(orientations, list) or not orientations:
                errors.append("'page.orientations' must be a non-empty list.")
            else:
                for ori in orientations:
                    if ori not in VALID_ORIENTATIONS:
                        errors.append(f"Invalid orientation '{ori}'. Supported: {sorted(VALID_ORIENTATIONS)}")

        # Map Roles
        roles = data.get("map_roles", [])
        if not isinstance(roles, list) or not roles:
            errors.append("'map_roles' must be a non-empty list of role definitions.")
        else:
            role_ids = set()
            has_required = False
            for r in roles:
                if not isinstance(r, dict):
                    errors.append("Each map role entry must be an object.")
                    continue
                r_id = r.get("id")
                if not r_id:
                    errors.append("Map role entry is missing 'id'.")
                elif r_id in role_ids:
                    errors.append(f"Duplicate map role id '{r_id}'.")
                else:
                    role_ids.add(r_id)

                if r.get("required") is True:
                    has_required = True

            if not has_required:
                errors.append("Template must specify at least one required map role.")

        # File paths check if base_dir is supplied
        if base_dir:
            qpt_rel = data.get("qpt_path")
            if qpt_rel:
                # Disallow path traversal
                if ".." in qpt_rel or os.path.isabs(qpt_rel):
                    errors.append(f"Unsafe qpt_path '{qpt_rel}'. Path traversal is forbidden.")
                else:
                    full_qpt = os.path.join(base_dir, qpt_rel)
                    if not os.path.isfile(full_qpt):
                        errors.append(f"Referenced layout file does not exist: {qpt_rel}")

            preview_rel = data.get("preview_path")
            if preview_rel and ".." in preview_rel:
                errors.append(f"Unsafe preview_path '{preview_rel}'. Path traversal is forbidden.")

        return len(errors) == 0, errors
