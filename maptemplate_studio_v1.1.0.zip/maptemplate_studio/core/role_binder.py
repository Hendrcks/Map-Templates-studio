"""
Role Binder for MapTemplate Studio.
Binds layout items (maps, legends, scalebars, north arrows, labels, and logos)
to project layers, extents, and cartographic metadata.
"""

from typing import Dict, Any, List, Optional
import os

try:
    from qgis.core import (
        QgsPrintLayout,
        QgsLayoutItemMap,
        QgsLayoutItemLabel,
        QgsLayoutItemLegend,
        QgsLayoutItemScaleBar,
        QgsLayoutItemPicture,
        QgsUnitTypes,
        QgsProject,
        QgsCoordinateReferenceSystem,
    )
    HAS_QGIS_CORE = True
except ImportError:
    HAS_QGIS_CORE = False

from .extent_scale import ExtentScaleResolver
from .asset_resolver import AssetResolver


class RoleBinder:
    """Coordinates the binding of project layers and user metadata to QGIS Print Layout items."""

    @classmethod
    def bind_all(
        cls,
        layout: "QgsPrintLayout",
        role_layers: Dict[str, List[Any]],
        role_extents: Dict[str, Any],
        metadata: Dict[str, str],
        legend_config: Optional[Dict[str, Any]] = None,
        scalebar_config: Optional[Dict[str, Any]] = None,
        logo_path: Optional[str] = None,
    ) -> Dict[str, bool]:
        """
        Binds all configuration onto the QgsPrintLayout.
        Returns a summary report of bound items.
        """
        if not HAS_QGIS_CORE or not layout:
            return {}

        results = {
            "maps_bound": 0,
            "labels_bound": 0,
            "legend_bound": False,
            "scalebar_bound": False,
            "north_arrow_bound": False,
            "logo_bound": False,
        }

        # 1. Map Items Binding
        main_map_item = None
        for item in layout.items():
            if isinstance(item, QgsLayoutItemMap):
                item_id = item.id() or "main_map"
                # If we haven't designated a main_map yet, pick the first map
                if item_id == "main_map" or main_map_item is None:
                    main_map_item = item

                # Bind layers if provided for this role
                if item_id in role_layers and role_layers[item_id]:
                    item.setLayers(role_layers[item_id])
                    item.setKeepLayerSet(True)

                # Bind extent
                if item_id in role_extents and role_extents[item_id]:
                    target_extent = role_extents[item_id]
                    frame_w = item.rect().width()
                    frame_h = item.rect().height()
                    fitted = ExtentScaleResolver.fit_extent_to_frame(
                        target_extent=target_extent,
                        frame_width_mm=frame_w,
                        frame_height_mm=frame_h,
                        padding_pct=5.0,
                    )
                    item.zoomToExtent(fitted)
                    results["maps_bound"] += 1

        # 2. Labels / Marginalia Binding
        label_mappings = {
            "title": metadata.get("title", ""),
            "subtitle": metadata.get("subtitle", ""),
            "source": f"Data Source: {metadata.get('source', '')}" if metadata.get("source") else "",
            "sources": f"Data Sources: {metadata.get('source', '')}" if metadata.get("source") else "",
            "author": f"Cartographer: {metadata.get('author', '')}" if metadata.get("author") else "",
            "organization": metadata.get("organization", ""),
            "date": f"Date: {metadata.get('date', '')}" if metadata.get("date") else "",
            "crs": f"Projection / CRS: {metadata.get('crs', '')}" if metadata.get("crs") else "",
            "notes": metadata.get("notes", ""),
        }

        for item in layout.items():
            if isinstance(item, QgsLayoutItemLabel):
                lbl_id = (item.id() or "").lower()
                for key, val in label_mappings.items():
                    if key in lbl_id and val:
                        item.setText(val)
                        results["labels_bound"] += 1
                        break

        # 3. Legend Binding
        for item in layout.items():
            if isinstance(item, QgsLayoutItemLegend):
                if main_map_item:
                    item.setLinkedMap(main_map_item)
                if legend_config:
                    if "title" in legend_config:
                        item.setTitle(legend_config["title"])
                    if "columns" in legend_config and legend_config["columns"] > 1:
                        item.setColumnCount(legend_config["columns"])
                    if legend_config.get("filter_by_map"):
                        item.setLegendFilterByMapEnabled(True)
                item.updateLegend()
                results["legend_bound"] = True
                break

        # 4. Scale Bar Binding
        for item in layout.items():
            if isinstance(item, QgsLayoutItemScaleBar):
                if main_map_item:
                    item.setLinkedMap(main_map_item)
                if scalebar_config:
                    units_str = scalebar_config.get("units", "km").lower()
                    if units_str in ("km", "kilometers"):
                        item.setUnits(QgsUnitTypes.DistanceUnit.DistanceKilometers)
                        item.setUnitLabel("km")
                    elif units_str in ("m", "meters"):
                        item.setUnits(QgsUnitTypes.DistanceUnit.DistanceMeters)
                        item.setUnitLabel("m")
                    elif units_str in ("mi", "miles"):
                        item.setUnits(QgsUnitTypes.DistanceUnit.DistanceMiles)
                        item.setUnitLabel("mi")

                    segments = scalebar_config.get("segments", 2)
                    item.setNumberOfSegments(max(1, segments))
                results["scalebar_bound"] = True
                break

        # 5. North Arrow Binding
        for item in layout.items():
            if isinstance(item, QgsLayoutItemPicture):
                pic_id = (item.id() or "").lower()
                if "north" in pic_id or "arrow" in pic_id:
                    if main_map_item:
                        item.setLinkedMap(main_map_item)
                    default_svg = AssetResolver.get_default_north_arrow_svg()
                    if default_svg and (not item.picturePath() or not os.path.isfile(item.picturePath())):
                        item.setPicturePath(default_svg)
                    results["north_arrow_bound"] = True
                elif "logo" in pic_id:
                    if logo_path and os.path.isfile(logo_path):
                        item.setPicturePath(logo_path)
                        results["logo_bound"] = True

        return results
