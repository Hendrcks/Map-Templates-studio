"""
Paper & Canvas Size Registry for MapTemplate Studio.
Provides standard ISO, North American (ANSI/Architectural), Digital, and Custom
paper size definitions along with orientation-aware millimeter resolution.
"""

from typing import Dict, Any, List, Optional, Tuple


PAPER_SIZE_PRESETS: List[Dict[str, Any]] = [
    # ISO A & B Series
    {
        "id": "A4",
        "label": "A4 — ISO Standard",
        "short_mm": 210.0,
        "long_mm": 297.0,
        "category": "ISO",
    },
    {
        "id": "A3",
        "label": "A3 — ISO Medium Sheet",
        "short_mm": 297.0,
        "long_mm": 420.0,
        "category": "ISO",
    },
    {
        "id": "A2",
        "label": "A2 — ISO Large Wall Sheet",
        "short_mm": 420.0,
        "long_mm": 594.0,
        "category": "ISO",
    },
    {
        "id": "A1",
        "label": "A1 — ISO Technical Plot",
        "short_mm": 594.0,
        "long_mm": 841.0,
        "category": "ISO",
    },
    {
        "id": "A0",
        "label": "A0 — ISO Full Exhibition Poster",
        "short_mm": 841.0,
        "long_mm": 1189.0,
        "category": "ISO",
    },
    {
        "id": "A5",
        "label": "A5 — ISO Compact Booklet",
        "short_mm": 148.0,
        "long_mm": 210.0,
        "category": "ISO",
    },
    {
        "id": "B4",
        "label": "B4 — ISO Atlas Folio",
        "short_mm": 250.0,
        "long_mm": 353.0,
        "category": "ISO",
    },
    {
        "id": "B3",
        "label": "B3 — ISO Wide Wall Chart",
        "short_mm": 353.0,
        "long_mm": 500.0,
        "category": "ISO",
    },
    # North American / ANSI & Architectural
    {
        "id": "Letter",
        "label": "Letter — US Letter (ANSI A)",
        "short_mm": 215.9,
        "long_mm": 279.4,
        "category": "North American",
    },
    {
        "id": "Legal",
        "label": "Legal — US Legal Brief",
        "short_mm": 215.9,
        "long_mm": 355.6,
        "category": "North American",
    },
    {
        "id": "Tabloid",
        "label": "Tabloid — US Ledger (ANSI B)",
        "short_mm": 279.4,
        "long_mm": 431.8,
        "category": "North American",
    },
    {
        "id": "ANSI C",
        "label": "ANSI C — Engineering Sheet",
        "short_mm": 431.8,
        "long_mm": 558.8,
        "category": "North American",
    },
    {
        "id": "ANSI D",
        "label": "ANSI D — Architectural Sheet",
        "short_mm": 558.8,
        "long_mm": 863.6,
        "category": "North American",
    },
    {
        "id": "ANSI E",
        "label": "ANSI E — Full Engineering Plot",
        "short_mm": 863.6,
        "long_mm": 1117.6,
        "category": "North American",
    },
    {
        "id": "Arch D",
        "label": "Arch D — Blueprint Poster (24×36 in)",
        "short_mm": 609.6,
        "long_mm": 914.4,
        "category": "North American",
    },
    # Digital & Screen Formats
    {
        "id": "16:9",
        "label": "16:9 — Widescreen Presentation",
        "short_mm": 190.5,
        "long_mm": 338.7,
        "category": "Digital",
    },
    {
        "id": "4:3",
        "label": "4:3 — Standard Slide Deck",
        "short_mm": 203.2,
        "long_mm": 270.9,
        "category": "Digital",
    },
    {
        "id": "Square",
        "label": "Square — 1:1 Editorial / Social",
        "short_mm": 210.0,
        "long_mm": 210.0,
        "category": "Digital",
    },
    # Custom User Dimensions
    {
        "id": "Custom",
        "label": "Custom — Custom Dimensions (mm)...",
        "short_mm": None,
        "long_mm": None,
        "category": "Custom",
    },
]

_PRESET_MAP: Dict[str, Dict[str, Any]] = {p["id"]: p for p in PAPER_SIZE_PRESETS}


class PaperSizeRegistry:
    """Resolves standard and custom paper sizes into millimeter page dimensions."""

    MIN_DIMENSION_MM = 25.0
    MAX_DIMENSION_MM = 5000.0

    @classmethod
    def get_all_presets(cls, include_custom: bool = True) -> List[Dict[str, Any]]:
        """Returns ordered list of paper size definitions."""
        if include_custom:
            return list(PAPER_SIZE_PRESETS)
        return [p for p in PAPER_SIZE_PRESETS if p["id"] != "Custom"]

    @classmethod
    def get_preset(cls, size_id: str) -> Optional[Dict[str, Any]]:
        """Returns preset dictionary for a paper size ID, or None if unknown."""
        if not size_id:
            return None
        return _PRESET_MAP.get(size_id)

    @classmethod
    def get_valid_manifest_sizes(cls) -> set:
        """Returns all standard (non-custom) paper size IDs valid in template manifests."""
        return {p["id"] for p in PAPER_SIZE_PRESETS if p["id"] != "Custom"}

    @classmethod
    def clamp_mm(cls, val: float) -> float:
        return max(cls.MIN_DIMENSION_MM, min(cls.MAX_DIMENSION_MM, float(val)))

    @classmethod
    def resolve_dimensions_mm(
        cls,
        size_id: Optional[str],
        orientation: Optional[str] = "landscape",
        custom_width_mm: Optional[float] = None,
        custom_height_mm: Optional[float] = None,
        fallback_width_mm: float = 297.0,
        fallback_height_mm: float = 210.0,
    ) -> Tuple[float, float]:
        """
        Resolves (width_mm, height_mm) for the chosen paper size and orientation.
        For 'Custom', uses custom_width_mm and custom_height_mm directly.
        """
        ori = (orientation or "landscape").strip().lower()

        if size_id == "Custom":
            w = cls.clamp_mm(custom_width_mm if custom_width_mm is not None else fallback_width_mm)
            h = cls.clamp_mm(custom_height_mm if custom_height_mm is not None else fallback_height_mm)
            return round(w, 2), round(h, 2)

        preset = cls.get_preset(size_id) if size_id else None
        if not preset or preset["short_mm"] is None:
            # If only orientation was overridden against fallback dimensions
            if orientation:
                short_s = min(fallback_width_mm, fallback_height_mm)
                long_s = max(fallback_width_mm, fallback_height_mm)
                if ori == "portrait":
                    return round(short_s, 2), round(long_s, 2)
                return round(long_s, 2), round(short_s, 2)
            return round(fallback_width_mm, 2), round(fallback_height_mm, 2)

        short_mm = float(preset["short_mm"])
        long_mm = float(preset["long_mm"])

        if ori == "portrait":
            return round(short_mm, 2), round(long_mm, 2)
        return round(long_mm, 2), round(short_mm, 2)

    @classmethod
    def format_dim_number(cls, val: float) -> str:
        """Formats millimeter value concisely (e.g. 297 -> '297', 215.9 -> '215.9')."""
        if abs(val - round(val)) < 0.05:
            return str(int(round(val)))
        return f"{val:.1f}"

    @classmethod
    def format_combo_label(
        cls,
        size_id: str,
        orientation: str = "landscape",
        is_template_default: bool = False,
    ) -> str:
        """Builds a clear, human-readable label for paper size dropdown menus."""
        preset = cls.get_preset(size_id)
        if not preset:
            suffix = "  [Template Default]" if is_template_default else ""
            return f"{size_id}{suffix}"

        if size_id == "Custom":
            return preset["label"]

        w, h = cls.resolve_dimensions_mm(size_id, orientation)
        dim_str = f"{cls.format_dim_number(w)} × {cls.format_dim_number(h)} mm"
        default_tag = "  ★ Default" if is_template_default else ""
        return f"{preset['label']} ({dim_str}){default_tag}"

    @classmethod
    def format_dimensions_summary(cls, width_mm: float, height_mm: float) -> str:
        """Formats output dimensions in both millimeters and inches."""
        w_in = width_mm / 25.4
        h_in = height_mm / 25.4
        return (
            f"{cls.format_dim_number(width_mm)} × {cls.format_dim_number(height_mm)} mm  "
            f"({w_in:.2f} × {h_in:.2f} in)"
        )

