"""
Preflight Inspection Dialog for MapTemplate Studio.
Displays cartographic quality assurance results, readiness score, and remediation steps.
"""

from typing import Optional

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QDialog,
        QVBoxLayout,
        QHBoxLayout,
        QLabel,
        QTreeWidget,
        QTreeWidgetItem,
        QPushButton,
        QDialogButtonBox,
        QProgressBar,
        QFrame,
    )
    HAS_QT = True
except ImportError:
    HAS_QT = False

try:
    from ..core.preflight import PreflightReport
    from .theme import QGISTheme
except (ImportError, ValueError):
    from core.preflight import PreflightReport
    from ui.theme import QGISTheme


class PreflightDialog(QDialog):
    """Detailed visual inspector for cartographic preflight results."""

    def __init__(self, report: PreflightReport, parent=None):
        super().__init__(parent)
        self.report = report
        self.setWindowTitle("Cartographic Preflight Quality Check")
        self.setMinimumSize(620, 480)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(12, 12, 12, 12)

        # 1. Header Banner & Readiness Score
        header_frame = QFrame(self)
        header_frame.setFrameShape(QFrame.Shape.StyledPanel)
        h_layout = QHBoxLayout(header_frame)
        h_layout.setContentsMargins(10, 10, 10, 10)

        # Status text
        v_text = QVBoxLayout()
        title_lbl = QLabel("Cartographic QA Preflight Inspection", self)
        title_lbl.setStyleSheet("font-size: 13pt; font-weight: bold;")
        v_text.addWidget(title_lbl)

        status_text = "READY FOR PRODUCTION" if self.report.passed else "CARTOGRAPHIC BLOCKERS DETECTED"
        color = QGISTheme.COLOR_PASS if self.report.passed else QGISTheme.COLOR_BLOCK
        status_lbl = QLabel(status_text, self)
        status_lbl.setStyleSheet(f"font-weight: bold; color: {color};")
        v_text.addWidget(status_lbl)
        h_layout.addLayout(v_text)

        h_layout.addStretch()

        # Score Dial / Box
        score_box = QVBoxLayout()
        score_lbl = QLabel(f"{self.report.score}%", self)
        score_lbl.setStyleSheet(f"font-size: 22pt; font-weight: bold; color: {color};")
        score_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_sub = QLabel("Readiness Score", self)
        score_sub.setStyleSheet("font-size: 8pt; color: palette(mid);")
        score_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_box.addWidget(score_lbl)
        score_box.addWidget(score_sub)
        h_layout.addLayout(score_box)

        layout.addWidget(header_frame)

        # Summary Metrics Row
        metrics_row = QHBoxLayout()
        metrics_row.addWidget(QLabel(f"✓ Passed: {self.report.pass_count}", self))
        metrics_row.addWidget(QLabel(f"⚠ Warnings: {self.report.warning_count}", self))
        blockers = sum(1 for i in self.report.issues if i.severity == "BLOCK")
        metrics_row.addWidget(QLabel(f"⛔ Blockers: {blockers}", self))
        metrics_row.addStretch()
        layout.addLayout(metrics_row)

        # 2. Issues Tree
        self.tree = QTreeWidget(self)
        self.tree.setHeaderLabels(["Severity", "Code", "Item / Check", "Remediation Guidance"])
        self.tree.setColumnWidth(0, 85)
        self.tree.setColumnWidth(1, 95)
        self.tree.setColumnWidth(2, 200)

        for issue in self.report.issues:
            item = QTreeWidgetItem(self.tree)
            item.setText(0, issue.severity)
            item.setText(1, issue.code)
            item.setText(2, issue.title)
            item.setText(3, issue.remediation or issue.detail)

            # Styling by severity
            if issue.severity == "BLOCK":
                item.setForeground(0, QtGui.QBrush(QtGui.QColor(QGISTheme.COLOR_BLOCK)))
                item.setFont(0, QtGui.QFont("Segoe UI", -1, QtGui.QFont.Weight.Bold))
            elif issue.severity == "WARNING":
                item.setForeground(0, QtGui.QBrush(QtGui.QColor(QGISTheme.COLOR_WARNING)))
                item.setFont(0, QtGui.QFont("Segoe UI", -1, QtGui.QFont.Weight.Bold))
            else:
                item.setForeground(0, QtGui.QBrush(QtGui.QColor(QGISTheme.COLOR_PASS)))

        layout.addWidget(self.tree)

        # 3. Action Buttons
        btn_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, self)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)
