"""
Import Template Dialog for MapTemplate Studio.
Permits users to inspect and import personal .qpt layout files into their private catalog.
"""

import os
from typing import Optional

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
    from qgis.PyQt.QtCore import Qt, pyqtSignal
    from qgis.PyQt.QtWidgets import (
        QDialog,
        QVBoxLayout,
        QFormLayout,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QComboBox,
        QTextEdit,
        QPushButton,
        QFileDialog,
        QMessageBox,
        QDialogButtonBox,
        QGroupBox,
    )
    HAS_QT = True
except ImportError:
    HAS_QT = False

try:
    from ..core.template_importer import TemplateImporter
    from ..core.asset_resolver import AssetResolver
    from .theme import QGISTheme
except (ImportError, ValueError):
    from core.template_importer import TemplateImporter
    from core.asset_resolver import AssetResolver
    from ui.theme import QGISTheme


class ImportTemplateDialog(QDialog):
    """Dialog for importing custom .qpt files into the user's template library."""

    templateImported = pyqtSignal(str)  # Emits new template_id

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Import Custom Template (.qpt)")
        icon_path = AssetResolver.get_icon_path()
        if icon_path:
            self.setWindowIcon(QtGui.QIcon(icon_path))
        self.setMinimumWidth(540)
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(12)
        main_layout.setContentsMargins(14, 14, 14, 14)

        form = QFormLayout()
        form.setSpacing(10)

        # 1. File Selector Row
        file_row = QHBoxLayout()
        self.file_edit = QLineEdit(self)
        self.file_edit.setPlaceholderText("Select .qpt file...")
        self.file_edit.textChanged.connect(self._inspect_selected_file)
        file_row.addWidget(self.file_edit)

        self.browse_btn = QPushButton("Browse...", self)
        self.browse_btn.clicked.connect(self._browse_qpt)
        file_row.addWidget(self.browse_btn)
        form.addRow("Layout File (.qpt):", file_row)

        # Inspection Box
        self.inspect_box = QGroupBox("Layout Inspection", self)
        v_ins = QVBoxLayout(self.inspect_box)
        self.inspect_lbl = QLabel("No file selected for inspection.", self)
        self.inspect_lbl.setStyleSheet("color: palette(mid); font-size: 8.5pt;")
        v_ins.addWidget(self.inspect_lbl)
        form.addRow("", self.inspect_box)

        # 2. Template Metadata Inputs
        self.name_edit = QLineEdit(self)
        self.name_edit.setPlaceholderText("e.g. Corporate Standard A4")
        form.addRow("Display Name:", self.name_edit)

        self.family_combo = QComboBox(self)
        families = [
            ("General & Reference", "general"),
            ("Planning & Land", "planning"),
            ("Remote Sensing", "remote_sensing"),
            ("Environment & Hazards", "environment"),
            ("Terrain & Geology", "terrain"),
            ("Social & Health", "social"),
            ("Transport & Utilities", "transport"),
            ("Humanitarian", "humanitarian"),
            ("Surveying & Engineering", "surveying"),
            ("Atlas & Series", "atlas"),
            ("Academic & Educational", "academic"),
            ("Digital & Social", "digital"),
        ]
        for label, val in families:
            self.family_combo.addItem(label, val)
        form.addRow("Family Category:", self.family_combo)

        self.archetype_combo = QComboBox(self)
        archetypes = [
            ("Hero Map", "hero_map"),
            ("Right Rail", "right_rail"),
            ("Bottom Band", "bottom_band"),
            ("Split Compare", "split_compare"),
            ("Dashboard", "dashboard"),
            ("Atlas Sheet", "atlas_sheet"),
        ]
        for label, val in archetypes:
            self.archetype_combo.addItem(label, val)
        form.addRow("Page Archetype:", self.archetype_combo)

        # Page Size & Orientation
        page_row = QHBoxLayout()
        self.size_combo = QComboBox(self)
        for sz in ["A4", "A3", "A2", "A5", "16:9", "Letter", "Legal"]:
            self.size_combo.addItem(sz, sz)
        page_row.addWidget(self.size_combo)

        self.ori_combo = QComboBox(self)
        self.ori_combo.addItem("Landscape", "landscape")
        self.ori_combo.addItem("Portrait", "portrait")
        page_row.addWidget(self.ori_combo)
        form.addRow("Page Size & Orientation:", page_row)

        self.author_edit = QLineEdit(self)
        form.addRow("Author / Organization:", self.author_edit)

        self.desc_edit = QTextEdit(self)
        self.desc_edit.setMaximumHeight(65)
        self.desc_edit.setPlaceholderText("Brief description of layout purpose...")
        form.addRow("Description:", self.desc_edit)

        main_layout.addLayout(form)
        main_layout.addStretch()

        # Action Buttons
        self.btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            self,
        )
        self.import_btn = self.btn_box.button(QDialogButtonBox.StandardButton.Ok)
        self.import_btn.setText("Import Template")
        self.import_btn.setObjectName("PrimaryButton")

        self.btn_box.accepted.connect(self._do_import)
        self.btn_box.rejected.connect(self.reject)
        main_layout.addWidget(self.btn_box)

    def _browse_qpt(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select QGIS Layout Template",
            "",
            "QGIS Print Templates (*.qpt);;All Files (*.*)",
        )
        if path:
            self.file_edit.setText(path)

    def _inspect_selected_file(self, path: str):
        path = path.strip()
        if not path or not os.path.isfile(path):
            self.inspect_lbl.setText("No file selected.")
            return

        valid, summary, err = TemplateImporter.inspect_qpt(path)
        if not valid:
            self.inspect_lbl.setText(f"⚠ Inspection failed: {err}")
            self.inspect_lbl.setStyleSheet("color: #dc2626; font-size: 8.5pt;")
        else:
            self.inspect_lbl.setText(
                f"✓ Valid QGIS Template ({summary['file_size_kb']} KB)\n"
                f"• Maps: {summary['map_count']} | Labels: {summary['label_count']} | "
                f"Legends: {summary['legend_count']} | Scalebars: {summary['scalebar_count']}"
            )
            self.inspect_lbl.setStyleSheet("color: #16a34a; font-size: 8.5pt;")

            # Auto-fill name if blank
            if not self.name_edit.text():
                base = os.path.splitext(os.path.basename(path))[0]
                clean = base.replace("_", " ").replace("-", " ").title()
                self.name_edit.setText(clean)

    def _do_import(self):
        qpt_path = self.file_edit.text().strip()
        name = self.name_edit.text().strip()
        if not qpt_path or not os.path.isfile(qpt_path):
            QMessageBox.warning(self, "Invalid File", "Please choose a valid .qpt template file.")
            return
        if not name:
            QMessageBox.warning(self, "Name Required", "Please enter a display name for this template.")
            return

        success, t_id, err = TemplateImporter.import_template(
            source_qpt_path=qpt_path,
            display_name=name,
            family=self.family_combo.currentData(),
            archetype=self.archetype_combo.currentData(),
            page_size=self.size_combo.currentData(),
            orientation=self.ori_combo.currentData(),
            author=self.author_edit.text().strip(),
            description=self.desc_edit.toPlainText().strip(),
        )

        if success:
            QMessageBox.information(
                self,
                "Template Imported",
                f"Template '{name}' imported successfully as {t_id}!",
            )
            self.templateImported.emit(t_id)
            self.accept()
        else:
            QMessageBox.critical(self, "Import Failed", f"Could not import template:\n{err}")
