"""
Extent and Scale Fitting Service for MapTemplate Studio.
Implements cartographic frame-aspect fitting, margin padding, and CRS transformation.
"""

from typing import Optional, Tuple

try:
    from qgis.core import (
        QgsRectangle,
        QgsCoordinateReferenceSystem,
        QgsCoordinateTransform,
        QgsProject,
        QgsPointXY,
    )
    HAS_QGIS_CORE = True
except ImportError:
    HAS_QGIS_CORE = False


class ExtentScaleResolver:
    """Calculates fitted map extents and scales respecting aspect ratios and padding."""

    @classmethod
    def fit_extent_to_frame(
        cls,
        target_extent,
        frame_width_mm: float,
        frame_height_mm: float,
        padding_pct: float = 5.0,
        src_crs=None,
        dest_crs=None,
    ):
        """
        Calculates an extent that fits cleanly inside a map frame without distortion.

        :param target_extent: QgsRectangle or object with xMinimum, xMaximum, yMinimum, yMaximum
        :param frame_width_mm: Frame width in millimeters (> 0)
        :param frame_height_mm: Frame height in millimeters (> 0)
        :param padding_pct: Configurable padding percentage (0-50%)
        :param src_crs: Source QgsCoordinateReferenceSystem (optional)
        :param dest_crs: Target map QgsCoordinateReferenceSystem (optional)
        :return: Transformed and fitted QgsRectangle
        """
        if not HAS_QGIS_CORE:
            return target_extent

        if frame_width_mm <= 0 or frame_height_mm <= 0:
            frame_width_mm, frame_height_mm = 200.0, 150.0

        # Transform CRS if different
        extent = QgsRectangle(target_extent)
        if src_crs and dest_crs and src_crs != dest_crs:
            try:
                transform = QgsCoordinateTransform(src_crs, dest_crs, QgsProject.instance())
                extent = transform.transformBoundingBox(extent)
            except Exception:
                extent = QgsRectangle(target_extent)

        # Guard against zero or negative dimensions (e.g. single point or line)
        min_dim = 100.0  # fallback 100 map units
        if extent.width() <= 0:
            cx = extent.center().x()
            extent.setXMinimum(cx - min_dim / 2.0)
            extent.setXMaximum(cx + min_dim / 2.0)
        if extent.height() <= 0:
            cy = extent.center().y()
            extent.setYMinimum(cy - min_dim / 2.0)
            extent.setYMaximum(cy + min_dim / 2.0)

        # Apply aspect ratio fitting
        ratio_frame = frame_width_mm / frame_height_mm
        ratio_extent = extent.width() / extent.height()

        center = extent.center()
        w = extent.width()
        h = extent.height()

        if ratio_extent > ratio_frame:
            # Extent is wider than frame: expand height to match frame ratio
            new_h = w / ratio_frame
            new_w = w
        else:
            # Extent is taller than frame: expand width to match frame ratio
            new_w = h * ratio_frame
            new_h = h

        # Apply padding percentage (e.g. 5% adds 5% margin around content)
        pad_factor = 1.0 + (max(0.0, padding_pct) / 100.0)
        final_w = new_w * pad_factor
        final_h = new_h * pad_factor

        x_min = center.x() - (final_w / 2.0)
        x_max = center.x() + (final_w / 2.0)
        y_min = center.y() - (final_h / 2.0)
        y_max = center.y() + (final_h / 2.0)

        return QgsRectangle(x_min, y_min, x_max, y_max)

    @classmethod
    def calculate_scale(cls, extent, frame_width_mm: float) -> float:
        """
        Estimates the representative map scale denominator.
        For a projected CRS: scale = extent_width_meters / (frame_width_mm / 1000)
        """
        if not HAS_QGIS_CORE or frame_width_mm <= 0:
            return 10000.0
        width_m = extent.width()
        width_paper_m = frame_width_mm / 1000.0
        return width_m / width_paper_m if width_paper_m > 0 else 10000.0
