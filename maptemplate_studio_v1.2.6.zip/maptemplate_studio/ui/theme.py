"""
QGIS Software UI Theme Integration for MapTemplate Studio.
Dynamically inspects QGIS desktop palette (light/dark mode) and provides
native-looking stylesheets, icons, colors, and badge styling.
"""

from typing import Dict, Any

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
    from qgis.PyQt.QtGui import QPalette, QColor, QIcon
    from qgis.core import QgsApplication
    HAS_QT = True
except ImportError:
    HAS_QT = False


class QGISTheme:
    """Manages theme detection and dynamic QSS styling consistent with QGIS Desktop."""

    # QGIS Brand Cartographic Accents
    QGIS_GREEN = "#589632"
    QGIS_GREEN_HOVER = "#6cb03d"
    QGIS_GREEN_DARK = "#457726"
    QGIS_SLATE = "#2c3e50"
    
    # Semantic Status Colors
    COLOR_SUCCESS = "#16a34a"
    COLOR_PASS = COLOR_SUCCESS  # nosec B105
    COLOR_WARNING = "#d97706"
    COLOR_BLOCK = "#dc2626"

    @classmethod
    def is_dark_mode(cls) -> bool:
        """Detects if QGIS is running with a dark theme (e.g. Night Mapping)."""
        if not HAS_QT:
            return False
        app = QtWidgets.QApplication.instance()
        if not app:
            return False
        palette = app.palette()
        window_color = palette.color(QPalette.ColorRole.Window)
        # Luminance calculation (value < 128 indicates dark background)
        return window_color.value() < 128

    @classmethod
    def get_theme_colors(cls) -> Dict[str, str]:
        """Returns semantic theme color tokens matching current QGIS palette."""
        dark = cls.is_dark_mode()
        if dark:
            return {
                "window_bg": "#2b2b2b",
                "panel_bg": "#323232",
                "card_bg": "#3c3c3c",
                "card_hover": "#484848",
                "card_selected_border": cls.QGIS_GREEN_HOVER,
                "text_primary": "#f1f5f9",
                "text_secondary": "#94a3b8",
                "text_muted": "#64748b",
                "border": "#4b5563",
                "border_light": "#374151",
                "pill_bg": "#4b5563",
                "pill_text": "#e2e8f0",
                "header_bg": "#242424",
                "input_bg": "#1e1e1e",
                "input_border": "#4b5563",
                "accent_green": cls.QGIS_GREEN_HOVER,
            }
        else:
            return {
                "window_bg": "#f8fafc",
                "panel_bg": "#f1f5f9",
                "card_bg": "#ffffff",
                "card_hover": "#f8fafc",
                "card_selected_border": cls.QGIS_GREEN,
                "text_primary": "#0f172a",
                "text_secondary": "#475569",
                "text_muted": "#64748b",
                "border": "#cbd5e1",
                "border_light": "#e2e8f0",
                "pill_bg": "#f1f5f9",
                "pill_text": "#334155",
                "header_bg": "#ffffff",
                "input_bg": "#ffffff",
                "input_border": "#cbd5e1",
                "accent_green": cls.QGIS_GREEN,
            }

    @classmethod
    def get_theme_icon(cls, icon_name: str, fallback_icon=None) -> QIcon:
        """Retrieves a standard QGIS native theme icon with optional fallback."""
        if HAS_QT:
            try:
                icon = QgsApplication.getThemeIcon(icon_name)
                if not icon.isNull():
                    return icon
            except Exception:
                return fallback_icon or QIcon()
        return fallback_icon or QIcon()

    @classmethod
    def get_gallery_stylesheet(cls) -> str:
        """Returns standard QGIS-consistent stylesheet for the Gallery dock."""
        c = cls.get_theme_colors()
        return f"""
        QWidget#MapTemplateGallery {{
            background-color: {c["window_bg"]};
            color: {c["text_primary"]};
        }}
        QToolBar {{
            background: {c["header_bg"]};
            border-bottom: 1px solid {c["border"]};
            padding: 4px;
            spacing: 6px;
        }}
        QToolButton {{
            border: 1px solid transparent;
            border-radius: 4px;
            padding: 4px;
            background: transparent;
        }}
        QToolButton:hover {{
            background-color: {c["card_hover"]};
            border: 1px solid {c["border"]};
        }}
        QToolButton:checked {{
            background-color: {c["pill_bg"]};
            border: 1px solid {c["accent_green"]};
        }}
        QTreeWidget, QListWidget {{
            background-color: {c["panel_bg"]};
            border: 1px solid {c["border"]};
            border-radius: 4px;
            color: {c["text_primary"]};
        }}
        QTreeWidget::item:selected, QListWidget::item:selected {{
            background-color: {c["accent_green"]};
            color: #ffffff;
            border-radius: 3px;
        }}
        QScrollArea {{
            background-color: transparent;
            border: none;
        }}
        QFrame#TemplateCard {{
            background-color: {c["card_bg"]};
            border: 1px solid {c["border"]};
            border-radius: 6px;
        }}
        QFrame#TemplateCard:hover {{
            background-color: {c["card_hover"]};
            border: 1px solid {c["accent_green"]};
        }}
        QFrame#TemplateCard[selected="true"] {{
            border: 2px solid {c["card_selected_border"]};
            background-color: {c["card_hover"]};
        }}
        QLabel#CardTitle {{
            font-weight: bold;
            font-size: 11pt;
            color: {c["text_primary"]};
        }}
        QLabel#BadgePill {{
            background-color: {c["pill_bg"]};
            color: {c["pill_text"]};
            border: 1px solid {c["border_light"]};
            border-radius: 3px;
            padding: 2px 6px;
            font-size: 8pt;
        }}
        QPushButton#PrimaryButton {{
            background-color: {c["accent_green"]};
            color: #ffffff;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            padding: 6px 14px;
        }}
        QPushButton#PrimaryButton:hover {{
            background-color: {cls.QGIS_GREEN_HOVER};
        }}
        QPushButton#SecondaryButton {{
            background-color: {c["panel_bg"]};
            color: {c["text_primary"]};
            border: 1px solid {c["border"]};
            border-radius: 4px;
            padding: 5px 12px;
        }}
        QPushButton#SecondaryButton:hover {{
            background-color: {c["card_hover"]};
        }}
        QLineEdit, QComboBox, QSpinBox {{
            background-color: {c["input_bg"]};
            border: 1px solid {c["input_border"]};
            border-radius: 4px;
            padding: 4px 8px;
            color: {c["text_primary"]};
        }}
        QLineEdit:focus, QComboBox:focus {{
            border: 1px solid {c["accent_green"]};
        }}
        """

    @classmethod
    def get_wizard_stylesheet(cls) -> str:
        """Returns clean QGIS-consistent stylesheet for the Wizard dialog."""
        c = cls.get_theme_colors()
        return f"""
        QDialog#WizardDialog {{
            background-color: {c["window_bg"]};
            color: {c["text_primary"]};
        }}
        QTabWidget::pane {{
            border: 1px solid {c["border"]};
            border-radius: 4px;
            background-color: {c["card_bg"]};
            top: -1px;
        }}
        QTabBar::tab {{
            background: {c["panel_bg"]};
            border: 1px solid {c["border"]};
            border-bottom: none;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
            padding: 6px 16px;
            margin-right: 2px;
            color: {c["text_secondary"]};
        }}
        QTabBar::tab:selected {{
            background: {c["card_bg"]};
            color: {c["text_primary"]};
            font-weight: bold;
            border-bottom: 1px solid {c["card_bg"]};
        }}
        QGroupBox {{
            font-weight: bold;
            border: 1px solid {c["border"]};
            border-radius: 6px;
            margin-top: 10px;
            padding-top: 10px;
            background-color: {c["card_bg"]};
        }}
        QGroupBox::title {{
            subcontrol-origin: margin;
            subcontrol-position: top left;
            left: 10px;
            padding: 0 4px;
            color: {c["text_primary"]};
        }}
        """
