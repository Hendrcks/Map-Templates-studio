"""
Asset Resolver for MapTemplate Studio.
Resolves local assets, bundled graphics, north arrow SVGs, and fallback typography.
"""

import os
from pathlib import Path
from typing import Optional

try:
    from qgis.core import QgsApplication
    HAS_QGIS_APP = True
except ImportError:
    HAS_QGIS_APP = False


class AssetResolver:
    """Helper to locate and resolve graphics, templates, and font resources."""

    @staticmethod
    def get_plugin_dir() -> str:
        """Returns the root directory of this plugin."""
        return str(Path(__file__).resolve().parent.parent)

    @classmethod
    def get_templates_dir(cls) -> str:
        return os.path.join(cls.get_plugin_dir(), "templates")

    @classmethod
    def get_styles_dir(cls) -> str:
        return os.path.join(cls.get_plugin_dir(), "styles")

    @classmethod
    def get_schema_dir(cls) -> str:
        return os.path.join(cls.get_plugin_dir(), "schema")

    @classmethod
    def get_icon_path(cls) -> Optional[str]:
        path = os.path.join(cls.get_plugin_dir(), "icon.png")
        return path if os.path.isfile(path) else None

    @classmethod
    def get_logo_path(cls) -> Optional[str]:
        path = os.path.join(cls.get_plugin_dir(), "logo.png")
        return path if os.path.isfile(path) else None

    @classmethod
    def get_default_north_arrow_svg(cls) -> Optional[str]:
        """Finds standard QGIS north arrow SVG or returns fallback path."""
        if HAS_QGIS_APP:
            try:
                for svg_path in QgsApplication.svgPaths():
                    cand1 = os.path.join(svg_path, "arrows", "NorthArrow_02.svg")
                    cand2 = os.path.join(svg_path, "arrows", "Arrow_01.svg")
                    if os.path.isfile(cand1):
                        return cand1
                    if os.path.isfile(cand2):
                        return cand2
            except Exception:
                return None
        return None

    @classmethod
    def resolve_asset_path(cls, template_dir: str, rel_path: str) -> Optional[str]:
        """Resolves relative asset path inside template directory safely."""
        if not rel_path:
            return None
        # Disallow directory traversal
        if ".." in rel_path or os.path.isabs(rel_path):
            return None
        full_path = os.path.normpath(os.path.join(template_dir, rel_path))
        if os.path.isfile(full_path):
            return full_path
        return None

    @classmethod
    def get_fallback_font(cls) -> str:
        """Returns reliable cross-platform sans-serif font family."""
        return "Segoe UI, Arial, Liberation Sans, sans-serif"
