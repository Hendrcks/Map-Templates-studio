"""
Main Plugin Lifecycle Manager for MapTemplate Studio.
Handles QGIS Desktop GUI integration: menus, toolbars, actions, and dock widget.
"""

import os
import sys
from typing import Optional

# Ensure plugin directory is on sys.path
plugin_dir = os.path.dirname(os.path.abspath(__file__))
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QIcon
    try:
        from qgis.PyQt.QtGui import QAction
    except ImportError:
        from qgis.PyQt.QtWidgets import QAction

    from qgis.core import QgsApplication
    from qgis.gui import QgisInterface
    HAS_QGIS_GUI = True
except ImportError:
    HAS_QGIS_GUI = False

try:
    from .ui.gallery_dock import MapTemplateDockWidget
    from .ui.wizard_dialog import WizardDialog
    from .ui.import_template_dialog import ImportTemplateDialog
    from .core.catalog_service import CatalogService
except (ImportError, ValueError):
    from ui.gallery_dock import MapTemplateDockWidget
    from ui.wizard_dialog import WizardDialog
    from ui.import_template_dialog import ImportTemplateDialog
    from core.catalog_service import CatalogService


class MapTemplateStudioPlugin:
    """QGIS Desktop plugin entry point and lifecycle manager."""

    def __init__(self, iface: "QgisInterface"):
        self.iface = iface
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.dock_widget: Optional[MapTemplateDockWidget] = None
        self.actions = []
        self.toolbar = None
        self.menu_name = "&MapTemplate Studio"

    def initGui(self):
        """Initializes GUI elements when QGIS enables the plugin."""
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        icon = QIcon(icon_path) if os.path.isfile(icon_path) else QgsApplication.getThemeIcon("mActionNewLayout.svg")

        # 1. Action: Open Gallery Dock
        self.action_gallery = QAction(icon, "MapTemplate Studio Gallery", self.iface.mainWindow())
        self.action_gallery.setToolTip("Browse and generate production map layout templates")
        self.action_gallery.triggered.connect(self.show_gallery)
        self.actions.append(self.action_gallery)

        # 2. Action: New Layout from Template Wizard
        wizard_icon = QgsApplication.getThemeIcon("mActionAdd.svg")
        self.action_wizard = QAction(wizard_icon, "New Layout from Template...", self.iface.mainWindow())
        self.action_wizard.setToolTip("Launch guided layout creation wizard")
        self.action_wizard.triggered.connect(self.open_wizard)
        self.actions.append(self.action_wizard)

        # 3. Action: Import Custom Template
        import_icon = QgsApplication.getThemeIcon("mActionFolder.svg")
        self.action_import = QAction(import_icon, "Import Custom Template (.qpt)...", self.iface.mainWindow())
        self.action_import.setToolTip("Import a custom .qpt file into your template library")
        self.action_import.triggered.connect(self.open_import_dialog)
        self.actions.append(self.action_import)

        # Register under Plugins menu
        for action in self.actions:
            self.iface.addPluginToMenu(self.menu_name, action)

        # Add dedicated toolbar
        self.toolbar = self.iface.addToolBar("MapTemplate Studio")
        self.toolbar.setObjectName("MapTemplateStudioToolBar")
        self.toolbar.addAction(self.action_gallery)
        self.toolbar.addAction(self.action_wizard)

        # Instantiate and add Dock Widget
        self.dock_widget = MapTemplateDockWidget(iface=self.iface, parent=self.iface.mainWindow())
        self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock_widget)

    def unload(self):
        """Cleans up GUI elements when QGIS unloads/disables the plugin."""
        for action in self.actions:
            self.iface.removePluginMenu(self.menu_name, action)

        if self.toolbar:
            del self.toolbar

        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater()
            self.dock_widget = None

    def show_gallery(self):
        """Displays and focuses the MapTemplate Studio dock widget."""
        if self.dock_widget:
            self.dock_widget.show()
            self.dock_widget.raise_()
            self.dock_widget.activateWindow()

    def open_wizard(self):
        """Opens the layout creation wizard with the currently selected or first template."""
        catalog = CatalogService()
        all_templates = catalog.get_all()
        if not all_templates:
            QtWidgets.QMessageBox.warning(
                self.iface.mainWindow(),
                "No Templates",
                "No layout templates are currently available.",
            )
            return

        # Pick selected or default GEN-01
        chosen = all_templates[0]
        for t in all_templates:
            if t["id"] == "GEN-01":
                chosen = t
                break

        wizard = WizardDialog(chosen, iface=self.iface, parent=self.iface.mainWindow())
        wizard.exec()

    def open_import_dialog(self):
        """Opens the template import dialog."""
        dlg = ImportTemplateDialog(self.iface.mainWindow())
        if self.dock_widget:
            dlg.templateImported.connect(lambda t_id: self.dock_widget.refresh_gallery())
        dlg.exec()
