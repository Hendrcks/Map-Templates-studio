"""
Catalog Service for MapTemplate Studio.
Discovers, indexes, filters, and searches bundled and user-custom map layout templates.
"""

import os
import json
from typing import List, Dict, Any, Optional

from .asset_resolver import AssetResolver
from .settings_service import SettingsService
from .manifest_validator import ManifestValidator


class CatalogService:
    """Manages the template catalog discovery, metadata caching, and search queries."""

    def __init__(self, templates_dir: Optional[str] = None, settings: Optional[SettingsService] = None):
        self._bundled_dir = templates_dir or AssetResolver.get_templates_dir()
        self._settings = settings or SettingsService()
        self._catalog: Dict[str, Dict[str, Any]] = {}
        self.reload()

    def reload(self):
        """Scans bundled and custom directories and updates the cached index."""
        self._catalog.clear()

        # 1. Bundled templates
        if os.path.isdir(self._bundled_dir):
            for entry in os.listdir(self._bundled_dir):
                tdir = os.path.join(self._bundled_dir, entry)
                if os.path.isdir(tdir):
                    self._index_template_dir(tdir, is_custom=False)

        # 2. User custom templates
        custom_dir = self._settings.get_custom_templates_dir()
        if os.path.isdir(custom_dir):
            for entry in os.listdir(custom_dir):
                tdir = os.path.join(custom_dir, entry)
                if os.path.isdir(tdir):
                    self._index_template_dir(tdir, is_custom=True)

    def _index_template_dir(self, tdir: str, is_custom: bool):
        manifest_path = os.path.join(tdir, "manifest.json")
        if not os.path.isfile(manifest_path):
            return

        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return

        valid, errors = ManifestValidator.validate_dict(data, base_dir=tdir)
        if not valid:
            return

        t_id = data["id"]
        qpt_path = os.path.normpath(os.path.join(tdir, data["qpt_path"]))
        preview_rel = data.get("preview_path", "preview.png")
        preview_path = os.path.normpath(os.path.join(tdir, preview_rel))

        record = dict(data)
        record["qpt_abs_path"] = qpt_path
        record["preview_abs_path"] = preview_path if os.path.isfile(preview_path) else None
        record["is_custom"] = is_custom
        record["template_dir"] = tdir

        self._catalog[t_id] = record

    def get_template(self, template_id: str) -> Optional[Dict[str, Any]]:
        """Retrieves a single template record by ID."""
        rec = self._catalog.get(template_id)
        if rec:
            res = dict(rec)
            res["is_favorite"] = self._settings.is_favorite(template_id)
            return res
        return None

    def get_all(self) -> List[Dict[str, Any]]:
        """Returns all registered templates enriched with favorite status."""
        items = []
        for t_id, rec in self._catalog.items():
            item = dict(rec)
            item["is_favorite"] = self._settings.is_favorite(t_id)
            items.append(item)
        return items

    def filter(
        self,
        query: str = "",
        family: Optional[str] = None,
        archetype: Optional[str] = None,
        page_size: Optional[str] = None,
        orientation: Optional[str] = None,
        favorites_only: bool = False,
        recent_only: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Filters and sorts the catalog based on user criteria.
        """
        all_items = self.get_all()
        results = []

        favorites = set(self._settings.get_favorites())
        recently_used = self._settings.get_recently_used()

        q = query.lower().strip() if query else ""

        for item in all_items:
            t_id = item["id"]

            # Filter favorites
            if favorites_only and t_id not in favorites:
                continue

            # Filter recently used
            if recent_only and t_id not in recently_used:
                continue

            # Filter family
            if family and family != "all" and item.get("family") != family:
                continue

            # Filter archetype
            if archetype and archetype != "all" and item.get("archetype") != archetype:
                continue

            # Filter page size
            if page_size and page_size != "all":
                sizes = item.get("page", {}).get("sizes", [])
                if page_size not in sizes:
                    continue

            # Filter orientation
            if orientation and orientation != "all":
                orientations = item.get("page", {}).get("orientations", [])
                if orientation not in orientations:
                    continue

            # Text search (id, display_name, description, style_tags, archetype)
            if q:
                searchable_text = " ".join([
                    t_id.lower(),
                    item.get("display_name", "").lower(),
                    item.get("description", "").lower(),
                    item.get("family", "").lower(),
                    item.get("archetype", "").lower(),
                    " ".join(item.get("style_tags", [])).lower(),
                ])
                if q not in searchable_text:
                    continue

            results.append(item)

        # Sort: recently used first if requested, otherwise by family and ID
        if recent_only:
            recent_order = {tid: i for i, tid in enumerate(recently_used)}
            results.sort(key=lambda x: recent_order.get(x["id"], 999))
        else:
            results.sort(key=lambda x: (x.get("family", ""), x.get("id", "")))

        return results

    def get_counts(self) -> Dict[str, Any]:
        """Returns statistics for category badges."""
        all_items = self.get_all()
        family_counts: Dict[str, int] = {}
        for item in all_items:
            fam = item.get("family", "other")
            family_counts[fam] = family_counts.get(fam, 0) + 1

        fav_count = sum(1 for item in all_items if item["is_favorite"])
        recent_count = len(self._settings.get_recently_used())

        return {
            "total": len(all_items),
            "families": family_counts,
            "favorites": fav_count,
            "recently_used": recent_count,
        }
