"""
MapTemplate Studio - QGIS Plugin
A high-resolution, cartography-ready QGIS print layout template studio.
"""

import os
import sys

__version__ = "1.2.6"

# Ensure plugin root directory is added to sys.path so submodules can be resolved
plugin_dir = os.path.dirname(os.path.abspath(__file__))
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)


def classFactory(iface):
    """Load MapTemplateStudioPlugin class from file main_plugin.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .main_plugin import MapTemplateStudioPlugin
    return MapTemplateStudioPlugin(iface)
