"""
Layout Factory for MapTemplate Studio.
Constructs, populates, resizes, and registers QGIS Print Layouts non-destructively.
"""

import os
from typing import Dict, Any, List, Optional, Tuple

try:
    from qgis.core import (
        QgsProject,
        QgsPrintLayout,
        QgsReadWriteContext,
        QgsMasterLayoutInterface,
        QgsLayoutItem,
        QgsLayoutItemPage,
        QgsLayoutItemMap,
        QgsLayoutItemLabel,
        QgsLayoutItemLegend,
        QgsLayoutItemScaleBar,
        QgsLayoutItemShape,
        QgsLayoutPoint,
        QgsLayoutSize,
        QgsLayoutMeasurement,
        QgsUnitTypes,
        QgsLegendStyle,
    )
    from qgis.PyQt.QtXml import QDomDocument
    HAS_QGIS_CORE = True
except ImportError:
    HAS_QGIS_CORE = False

from .role_binder import RoleBinder
from .paper_sizes import PaperSizeRegistry
from .extent_scale import ExtentScaleResolver


class LayoutFactory:
    """Instantiates QgsPrintLayouts from .qpt templates and commits them safely to QGIS projects."""

    @classmethod
    def get_unique_layout_name(cls, project: "QgsProject", base_name: str) -> str:
        """Ensures layout name does not collide with existing layouts in the project."""
        if not HAS_QGIS_CORE or not project:
            return base_name

        existing_names = set(
            layout_obj.name() for layout_obj in project.layoutManager().printLayouts()
        )
        if base_name not in existing_names:
            return base_name

        counter = 1
        while f"{base_name} ({counter})" in existing_names:
            counter += 1
        return f"{base_name} ({counter})"

    @classmethod
    def resize_layout_to_page(
        cls,
        layout: "QgsPrintLayout",
        target_width_mm: float,
        target_height_mm: float,
    ) -> bool:
        """
        Proportionally resizes a QgsPrintLayout page and repositions/scales all
        cartographic layout items, typography, and strokes to fit target_width_mm × target_height_mm.
        """
        if not HAS_QGIS_CORE or not layout:
            return False

        page_coll = layout.pageCollection()
        if not page_coll or page_coll.pageCount() == 0:
            return False

        first_page = page_coll.page(0)
        orig_w = float(first_page.pageSize().width())
        orig_h = float(first_page.pageSize().height())
        if orig_w <= 0.0 or orig_h <= 0.0:
            return False

        if abs(target_width_mm - orig_w) <= 0.1 and abs(target_height_mm - orig_h) <= 0.1:
            return True

        sx = target_width_mm / orig_w
        sy = target_height_mm / orig_h
        s_min = min(sx, sy)
        # Optical typography scaling: crisp enlargement on large-format sheets (A3-A0),
        # exact proportional reduction on compact sheets (A5 / Portrait) to prevent clipping.
        s_typo = (s_min ** 0.8) if s_min > 1.0 else s_min

        # Snapshot original item geometry prior to modifying page collection
        snapshots = []
        for item in layout.items():
            if not isinstance(item, QgsLayoutItem) or isinstance(item, QgsLayoutItemPage):
                continue
            if hasattr(item, "parentGroup") and item.parentGroup() is not None:
                continue

            page_idx = item.page() if hasattr(item, "page") and item.page() >= 0 else 0
            pos = item.pagePositionWithUnits() if hasattr(item, "pagePositionWithUnits") else item.positionWithUnits()
            sz = item.sizeWithUnits()
            snapshots.append((
                item,
                page_idx,
                float(pos.x()),
                float(pos.y()),
                float(sz.width()),
                float(sz.height()),
            ))

        # Apply new page dimensions across all pages in the layout
        mm_unit = QgsUnitTypes.LayoutUnit.LayoutMillimeters
        for idx in range(page_coll.pageCount()):
            page_coll.page(idx).setPageSize(
                QgsLayoutSize(target_width_mm, target_height_mm, mm_unit)
            )

        # Transform all layout items proportionally
        for item, page_idx, ox, oy, ow, oh in snapshots:
            nx = ox * sx
            ny = oy * sy
            nw = max(1.0, ow * sx)
            nh = max(1.0, oh * sy)

            item.attemptMove(QgsLayoutPoint(nx, ny, mm_unit))
            item.attemptResize(QgsLayoutSize(nw, nh, mm_unit))

            # Adjust map viewport default extent to match new frame aspect ratio
            if isinstance(item, QgsLayoutItemMap):
                curr_ext = item.extent()
                if curr_ext and not curr_ext.isEmpty():
                    fitted_ext = ExtentScaleResolver.fit_extent_to_frame(
                        target_extent=curr_ext,
                        frame_width_mm=nw,
                        frame_height_mm=nh,
                        padding_pct=0.0,
                    )
                    if fitted_ext is not None:
                        item.zoomToExtent(fitted_ext)

            # Scale label typography
            elif isinstance(item, QgsLayoutItemLabel):
                fmt = item.textFormat() if hasattr(item, "textFormat") else None
                if fmt is not None and hasattr(fmt, "size") and hasattr(fmt, "setSize"):
                    old_size = float(fmt.size())
                    if old_size > 0.0:
                        new_size = max(5.5, min(72.0, round(old_size * s_typo, 1)))
                        fmt.setSize(new_size)
                        font = fmt.font() if hasattr(fmt, "font") else None
                        if font is not None and hasattr(font, "setPointSizeF"):
                            font.setPointSizeF(new_size)
                            fmt.setFont(font)
                        item.setTextFormat(fmt)

            # Scale legend typography and symbol patches
            elif isinstance(item, QgsLayoutItemLegend):
                if hasattr(item, "style") and hasattr(item, "setStyle"):
                    for style_type in (
                        QgsLegendStyle.Style.Title,
                        QgsLegendStyle.Style.Group,
                        QgsLegendStyle.Style.Subgroup,
                        QgsLegendStyle.Style.SymbolLabel,
                    ):
                        st = item.style(style_type)
                        if st is not None and hasattr(st, "textFormat") and hasattr(st, "setTextFormat"):
                            fmt = st.textFormat()
                            if fmt is not None and hasattr(fmt, "size") and hasattr(fmt, "setSize"):
                                old_sz = float(fmt.size())
                                if old_sz > 0.0:
                                    new_sz = max(5.5, min(48.0, round(old_sz * s_typo, 1)))
                                    fmt.setSize(new_sz)
                                    fnt = fmt.font() if hasattr(fmt, "font") else None
                                    if fnt is not None and hasattr(fnt, "setPointSizeF"):
                                        fnt.setPointSizeF(new_sz)
                                        fmt.setFont(fnt)
                                    st.setTextFormat(fmt)
                                    item.setStyle(style_type, st)
                if hasattr(item, "symbolWidth") and hasattr(item, "setSymbolWidth"):
                    item.setSymbolWidth(max(3.0, round(item.symbolWidth() * s_typo, 2)))
                if hasattr(item, "symbolHeight") and hasattr(item, "setSymbolHeight"):
                    item.setSymbolHeight(max(2.0, round(item.symbolHeight() * s_typo, 2)))

            # Scale scalebar typography and bar height
            elif isinstance(item, QgsLayoutItemScaleBar):
                if hasattr(item, "textFormat") and hasattr(item, "setTextFormat"):
                    fmt = item.textFormat()
                    if fmt is not None and hasattr(fmt, "size") and hasattr(fmt, "setSize"):
                        old_sz = float(fmt.size())
                        if old_sz > 0.0:
                            new_sz = max(5.5, min(36.0, round(old_sz * s_typo, 1)))
                            fmt.setSize(new_sz)
                            fnt = fmt.font() if hasattr(fmt, "font") else None
                            if fnt is not None and hasattr(fnt, "setPointSizeF"):
                                fnt.setPointSizeF(new_sz)
                                fmt.setFont(fnt)
                            item.setTextFormat(fmt)
                if hasattr(item, "height") and hasattr(item, "setHeight"):
                    item.setHeight(max(1.5, min(10.0, round(item.height() * s_typo, 2))))

            # Scale shape symbol stroke width
            elif isinstance(item, QgsLayoutItemShape):
                sym = item.symbol() if hasattr(item, "symbol") else None
                if sym is not None and hasattr(sym, "symbolLayerCount") and sym.symbolLayerCount() > 0:
                    sl = sym.symbolLayer(0)
                    if sl is not None and hasattr(sl, "strokeWidth") and hasattr(sl, "setStrokeWidth"):
                        old_sw = float(sl.strokeWidth())
                        if old_sw > 0.0:
                            sl.setStrokeWidth(max(0.12, min(2.5, round(old_sw * s_typo, 2))))

            # Scale item frame stroke width if enabled
            if item.frameEnabled() and hasattr(item, "frameStrokeWidth") and hasattr(item, "setFrameStrokeWidth"):
                frame_meas = item.frameStrokeWidth()
                if frame_meas is not None and hasattr(frame_meas, "length"):
                    old_fw = float(frame_meas.length())
                    if old_fw > 0.0:
                        new_fw = max(0.12, min(2.5, round(old_fw * s_typo, 2)))
                        item.setFrameStrokeWidth(QgsLayoutMeasurement(new_fw, mm_unit))

        layout.refresh()
        return True

    @classmethod
    def create_layout_from_template(
        cls,
        qpt_path: str,
        layout_name: str,
        role_layers: Optional[Dict[str, List[Any]]] = None,
        role_extents: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, str]] = None,
        legend_config: Optional[Dict[str, Any]] = None,
        scalebar_config: Optional[Dict[str, Any]] = None,
        logo_path: Optional[str] = None,
        project: Optional["QgsProject"] = None,
        page_size: Optional[str] = None,
        orientation: Optional[str] = None,
        custom_width_mm: Optional[float] = None,
        custom_height_mm: Optional[float] = None,
        role_paddings: Optional[Dict[str, float]] = None,
    ) -> Tuple[Optional["QgsPrintLayout"], Optional[str]]:
        """
        Creates, optionally resizes to the preferred paper size & orientation, binds,
        and adds a new QgsPrintLayout to the project.
        Returns (layout, error_message).
        """
        if not HAS_QGIS_CORE:
            return None, "QGIS core library not available."

        project = project or QgsProject.instance()
        if not project:
            return None, "No active QGIS project."

        if not os.path.isfile(qpt_path):
            return None, f"Template file does not exist: {qpt_path}"

        # 1. Read .qpt XML
        try:
            with open(qpt_path, "r", encoding="utf-8") as f:
                xml_content = f.read()
        except Exception as e:
            return None, f"Failed to read template file: {e}"

        doc = QDomDocument()
        if not doc.setContent(xml_content):
            return None, "Template XML is malformed."

        # 2. Instantiate new layout
        unique_name = cls.get_unique_layout_name(project, layout_name)
        layout = QgsPrintLayout(project)

        context = QgsReadWriteContext()
        loaded_items, ok = layout.loadFromTemplate(doc, context)
        if not ok and not loaded_items:
            return None, "Failed to instantiate layout items from template XML."

        # Ensure requested unique layout name is applied after template load
        layout.setName(unique_name)

        # 2b. Apply user-selected paper size and orientation before binding map extents
        if page_size or orientation or (custom_width_mm is not None and custom_height_mm is not None):
            page_coll = layout.pageCollection()
            orig_w = float(page_coll.page(0).pageSize().width()) if page_coll and page_coll.pageCount() > 0 else 297.0
            orig_h = float(page_coll.page(0).pageSize().height()) if page_coll and page_coll.pageCount() > 0 else 210.0
            target_w, target_h = PaperSizeRegistry.resolve_dimensions_mm(
                size_id=page_size,
                orientation=orientation,
                custom_width_mm=custom_width_mm,
                custom_height_mm=custom_height_mm,
                fallback_width_mm=orig_w,
                fallback_height_mm=orig_h,
            )
            cls.resize_layout_to_page(layout, target_w, target_h)
            layout.setCustomProperty("maptemplate_page_size", str(page_size or "Template Default"))
            layout.setCustomProperty("maptemplate_orientation", str(orientation or ("landscape" if target_w >= target_h else "portrait")))
            layout.setCustomProperty("maptemplate_dimensions_mm", f"{target_w}x{target_h}")

        # 3. Bind Roles, Extents, and Metadata (uses resized map frame rects!)
        RoleBinder.bind_all(
            layout=layout,
            role_layers=role_layers or {},
            role_extents=role_extents or {},
            metadata=metadata or {},
            legend_config=legend_config,
            scalebar_config=scalebar_config,
            logo_path=logo_path,
            role_paddings=role_paddings,
        )

        # 4. Attach metadata as custom layout variables
        if metadata:
            for k, v in metadata.items():
                layout.setCustomProperty(f"maptemplate_{k}", str(v))

        # 5. Safely register in the project layout manager
        project.layoutManager().addLayout(layout)

        return layout, None
